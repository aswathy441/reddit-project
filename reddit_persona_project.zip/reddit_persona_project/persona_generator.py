import os
import praw
from openai import OpenAI

# Manually define Reddit and OpenAI credentials
REDDIT_CLIENT_ID = "j4vK_fmSmmpAcS2IfOS0xQ"
REDDIT_CLIENT_SECRET = "lS5TTguUVmVcI17REf0H13xqmIrE4Q"
REDDIT_USER_AGENT = "persona-generator"
OPENAI_API_KEY ="AIzaSyB8B-pktDNPiZPU2GsPWSwvBeoHv7IqxMY"

client = OpenAI(api_key=OPENAI_API_KEY)

# Setup Reddit API instance
def get_reddit_instance():
    return praw.Reddit(
        client_id=REDDIT_CLIENT_ID,
        client_secret=REDDIT_CLIENT_SECRET,
        user_agent=REDDIT_USER_AGENT
    )

def scrape_user_content(username):
    reddit = get_reddit_instance()
    user = reddit.redditor(username)
    posts = []
    comments = []

    try:
        for submission in user.submissions.new(limit=10):
            if submission.selftext:
                posts.append(f"[Post] {submission.title}\n{submission.selftext}")
            else:
                posts.append(f"[Post] {submission.title}\n(No content)")

        for comment in user.comments.new(limit=10):
            comments.append(f"[Comment] {comment.body}")
    except Exception as e:
        print("Error while scraping user:", e)

    return posts, comments

# Function to generate user persona using OpenAI's new API
def generate_persona(posts, comments):
    combined_text = "\n\n".join(posts + comments)
    prompt = (
        "You are an AI assistant that creates user personas based on Reddit content.\n"
        "From the following posts and comments, write a detailed user persona.\n"
        "For each trait, hobby, interest, or personality type you list, cite the post or comment that supports it.\n\n"
        f"{combined_text}"
    )

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=1000
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Error calling OpenAI API: {e}"

# Main execution
def main():
    reddit_url = input("Enter Reddit profile URL: ").strip()
    username = reddit_url.rstrip("/").split("/")[-1]

    print(f"\n Scraping Reddit user: {username} ...")
    posts, comments = scrape_user_content(username)

    if not posts and not comments:
        print(" No content found for this user.")
        return

    print("\n Generating user persona with OpenAI...")
    persona = generate_persona(posts, comments)

    output_file = f"{username}_persona.txt"
    with open(output_file, "w", encoding="utf-8") as file:
        file.write(persona)

    print(f"\n Persona saved to: {output_file}")

if __name__ == "__main__":
    main()
